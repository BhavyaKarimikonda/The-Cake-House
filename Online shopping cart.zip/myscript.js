var first = document.forms["signupform"]["first"]
	var last = document.forms["signupform"]["last"]
	var email = document.forms["signupform"]["email"]
	var uid = document.forms["signupform"]["uid"]
	var password = document.forms["signupform"]["password"]

	var first_error = document.getElementById("first_error");
	var last_error = document.getElementById("last_error");
	var email_error = document.getElementById("email_error");
	var uid_error = document.getElementById("uid_error");
	var password_error = document.getElementById("password_error");

	first.addEventListener("blur",nameVerify,true);
	last.addEventListener("blur",nameVerify,true);
	email.addEventListener("blur",emailVerify,true);
	uid.addEventListener("blur",nameVerify,true);
	password.addEventListener("blur",passwordVerify,true);


	function Validate(){
		if(first.value=""){
			first.style.border = "1px solid red";
			first_error.textContent = "First name is required";
			first.focus();
			return false;
		}
		if(last.value=""){
			last.style.border = "1px solid red";
			last_error.textContent = "Last name is required";
			last.focus();
			return false;
		}
		if(email.value=""){
			email.style.border = "1px solid red";
			email_error.textContent = "Email is required";
			email.focus();
			return false;
		}
		if(password.value=""){
			password.style.border = "1px solid red";
			password_error.textContent = "Password is required";
			password.focus();
			return false;
		}
		if(uid.value=""){
			uid.style.border = "1px solid red";
			uid_error.textContent = "Id is required";
			uid.focus();
			return false;
		}
	}

	function nameVerify() {

		if(first.value !=""){
			first.style.border = "none";
			first_error.innerHTML = "";
			return true;}
	    if(last.value !=""){
			last.style.border = "none";
			last_error.innerHTML = "";
			return true;}

	}

	function emailVerify() {

		if(email.value !=""){
			email.style.border = "none";
			email_error.innerHTML = "";
			return true;
		}
	}

	function uidVerify() {

		if(uid.value !=""){
			uid.style.border = "none";
			uid_error.innerHTML = "";
			return true;
		}
	}

	function passwordVerify() {

		if(password.value !=""){
			password.style.border = "none";
			password_error.innerHTML = "";
			return true;
		}
	}

