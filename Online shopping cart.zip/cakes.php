
<?php
    include_once 'header.php';
    // if (isset($_POST['explore'])){
    include 'includes/dbh.inc.php' ;
    ?>
<br/>
<p style="font-weight: bold;font-size: 40px ; color: #814F12; font-style: italic; " align="center">I'm here for cupcakes </p><br/>
<br/>

<?php
    $query = "SELECT * FROM cakes ORDER BY cake_id ASC";
    $result = mysqli_query($conn,$query);
    if(mysqli_num_rows($result) > 0){
    	while($row = mysqli_fetch_array($result)){
    		?>
    		
    		<div style="margin-left: 70px; border: 1px solid #333;background-color: #f1f1f1; border-radius: 5px ;padding: 16px; width: 300px; height: 350px; display: inline-block;" >
    			<form method="POST" action="cakes.php?action=add&id=<?php echo $row["cake_id"]; ?>">
            <div class="mycakesclass">
            	<?php
        
            echo '<img src="'.$row["cake_image"].'" />' ;
            echo "<br>" ; echo "<br>" ;
            echo 'Flavour : '.$row["cake_name"].' ';
            echo "<br>" ;  echo "<br>" ;
            echo 'Price : ' .$row["cake_price"].' ';
            echo "<br>" ;  echo "<br>" ;
            echo 'Quantity : <input type="text" name="quantity" value="1" />' ;
            echo '<input type="hidden" name="hidden_name" value=" '.$row["cake_name"].'" /> '; 
            echo '<input type="hidden" name="hidden_price" value=" '.$row["cake_price"].'" />' ;  
            echo "<br>" ;  echo "<br>" ;
            echo '<input type="submit" name="add_to_cart" style="font-family:cursive;color:#fff;background-color:#814F12; cursor: pointer;" value="Add to cart"/> ' ;
            echo "<br>" ; 
            
            ?></div>
        </form>
        </div>
        
        <?php    

     }
     echo "<br>"; echo "<br>"; echo "<br>";
     ?>
     <form method="POST" action="mycart.php"> <?php
     echo '<input type="submit" name="go_to_cart" style="margin-left:550px;font-size:30px;font-family:cursive;color:#fff;background-color:#814F12; cursor: pointer;" value="Go to cart"/>' ; ?>
 </form>
 <?php

    } 
    ?>
   

<?php   
 if(isset($_POST["add_to_cart"]))  
 {  
      if(isset($_SESSION["shopping_cart"]))  
      {  
           $item_array_id = array_column($_SESSION["shopping_cart"], "item_id");  
           if(!in_array($_GET["id"], $item_array_id))  
           {  
                $count = count($_SESSION["shopping_cart"]);  
                $item_array = array(  
                     'item_id'               =>     $_GET["id"],  
                     'item_name'           =>     $_POST["hidden_name"],  
                     'item_price'          =>     $_POST["hidden_price"],  
                     'item_quantity'          =>     $_POST["quantity"]  
                );  
                $_SESSION["shopping_cart"][$count] = $item_array;  
           }  
           else  
           {  
                echo '<script>alert("Item Already Added")</script>';  
                echo '<script>window.location="cakes.php"</script>';  
           }  
      }  
      else  
      {  
           $item_array = array(  
                'item_id'               =>     $_GET["id"],  
                'item_name'           =>  $_POST["hidden_name"],  
                'item_price'          =>     $_POST["hidden_price"],  
                'item_quantity'          =>     $_POST["quantity"]  
           );  
           $_SESSION["shopping_cart"][0] = $item_array;  
      }  
 }  
 
 ?>





    