<?php
    include_once '../header.php';
    
    if(isset($_POST['explore'])){
    	echo 'Welcome to cakes page' ;
    }