 <?php
 include_once '../header.php';
 include 'dbh.inc.php' ;
 include '../mycart.php' ;
 if(isset($_POST['proceed'])){
 	if($_POST['pay'] == 'card' ){
	$card_number = mysqli_real_escape_string($conn,$_POST['card_number']);
	$cvv = mysqli_real_escape_string($conn,$_POST['cvv']);

	if(empty($card_number) || empty($cvv)){
         header("Location: ../pay.php?pay=empty");
	       exit();
	}else{
		$sql = "SELECT * FROM bank WHERE acc_num=".$card_number."";
		$result = mysqli_query($conn,$sql);
		$resultCheck = mysqli_num_rows($result);
		if($resultCheck < 1){
			header("Location: ../pay.php?card=".$card_number."");
	        exit();
		}else{	
			if($row = mysqli_fetch_assoc($result)){
				if($row['cvv'] != $cvv){
					header("Location: ../pay.php?cvv=error");
	                 exit();
				}
				else{
					if($row['amount']>=$total){
                          $row['amount'] =  $row['amount'] - $total ;
                          $update = "UPDATE bank SET amount = ".$row['amount']." WHERE acc_num=".$card_number."" ;
                          $res_update =  mysqli_query($conn,$update);
                          header("Location: ../success.php");
	                      exit();
					}
					else{
                           header("Location: ../pay.php?amount=null");
	                       exit();
					}
				}
			}
		}
	}
}

else{
     header("Location: ../success.php");
	                      exit();
}

}