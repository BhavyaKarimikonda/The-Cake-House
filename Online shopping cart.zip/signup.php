<?php
    include_once 'header.php';
    ?>

<section class="main-container">
	<div class="main-wrapper">
		<h2>SignUp</h2>
		<form class="signup-form" action="includes/signup.inc.php" method="POST" >
		  <div>
			<input type="text" name="first" placeholder="firstname">
			
		  </div>
		  <div>
			<input type="text" name="last" placeholder="lastname">
			
		  </div>
		  <div>
			<input type="text" name="email" placeholder="E-mail">
			
          </div>
          <div>
			<input type="text" name="uid" placeholder="Username">
           
		  </div>
		  <div>
			<input type="password" name="pwd" placeholder="Password">
			 
		  </div>
			<button type="submit" name="submit">Sign up</button>
		</form>
	</div>
</section>

























<?php
    include_once 'footer.php';
    ?>

