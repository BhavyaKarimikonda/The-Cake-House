<?php
    include_once 'header.php';
    // if (isset($_POST['explore'])){
     $total = 0;  
    include 'includes/dbh.inc.php' ;
    ?>

     <div style="clear:both"></div>  
                <br />  <br/> <br/>
                <p style="text-align: center; font-weight: bold;font-style: italic; font-size: 40px; color: #814F12; text-shadow: 0 0 2px #000;">Order Details</p>  <br/> 
                <div >  
                     <table class="mytable" align="center">  
                          <tr>  
                               <th width="40%">Item Name</th><br>  
                               <th width="10%">Quantity</th>  
                               <th width="20%">Price</th>  
                               <th width="15%">Total</th>  
                               <th width="5%">Action</th>  
                          </tr>  
                          <?php   
                          if(!empty($_SESSION["shopping_cart"]))  
                          {  
                               $total = 0;  
                               foreach($_SESSION["shopping_cart"] as $keys => $values)  
                               {  
                          ?>  
                          <tr>  
                               <td><?php echo $values["item_name"]; ?></td>  
                               <td><?php echo $values["item_quantity"]; ?></td>  
                               <td>$ <?php echo $values["item_price"]; ?></td>  
                               <td>$ <?php echo number_format($values["item_quantity"] * $values["item_price"], 2); ?></td>  
                               <td><a href="mycart.php?action=delete&id=<?php echo $values["item_id"]; ?>"><span >Remove</span></a></td>  
                          </tr>  
                          <?php  
                                    $total = $total + ($values["item_quantity"] * $values["item_price"]);  
                               }  
                          ?>  
                          <tr>  
                               <td colspan="3" align="right">Total</td>  
                               <td align="right">$ <?php echo number_format($total, 2); ?></td>  
                               <td></td>  
                          </tr>  
                          <?php  
                          }  
                          ?>  
                     </table>  
                </div>  
<div style="float: left; width: 130px">
      <form method="POST" action="cakes.php"> <?php
      echo "<br>"; echo "<br>"; echo "<br>";echo "<br>"; echo "<br>"; echo "<br>";echo "<br>"; echo "<br>"; echo "<br>";echo "<br>"; echo "<br>"; echo "<br>";
      echo '<input type="submit" name="continue_shopping" style="margin-left:700px;font-size:20px;font-family:cursive;color:#fff;background-color:#814F12; cursor: pointer;" value="Continue Shopping"/>' ; ?>
      </form>
</div>
<div style="float: right; width: 225px">
      <form method="POST" action="pay.php"> <?php
      if($total>"0"){
       echo "<br>"; echo "<br>"; echo "<br>";echo "<br>"; echo "<br>"; echo "<br>";echo "<br>"; echo "<br>"; echo "<br>";echo "<br>"; echo "<br>"; echo "<br>";
     echo '<input type="submit" name="pay_now" style="font-size:20px;font-family:cursive;color:#fff;background-color:#814F12; cursor: pointer;" value="Pay Now"/>' ;} ?>
      </form>
</div>
           </div>  
           <br />  
           <?php

           if(isset($_GET["action"]))  
 {  
      if($_GET["action"] == "delete")  
      {  
           foreach($_SESSION["shopping_cart"] as $keys => $values)  
           {  
                if($values["item_id"] == $_GET["id"])  
                {  
                     unset($_SESSION["shopping_cart"][$keys]);  
                     echo '<script>alert("Item Removed")</script>'; 
                     echo '<script>window.location="mycart.php"</script>';  
                }  
           }  
      }  
 }  

?>
