<?php
    include_once 'header.php';
    // if (isset($_POST['explore'])){
    include 'includes/dbh.inc.php' ;
    if(isset($_SESSION['u_id'])){
    ?>
<!DOCTYPE html>
<html>
    <head>
        <script src="jquery-1.11.0.js"></script>
        <script src="https://code.jquery.com/jquery-1.10.2.js"></script>
       
    </head>
    <body>
<section class="main-container">
	<div class="main-wrapper">
		<h2>Payment Details</h2>
		<form class="details-form" action="includes/pay.inc.php" method="POST">
			<input type="text" name="name" placeholder="Full Name">
			<input type="text" name="phone" placeholder="Phone Number">
			<input type="text" name="address" placeholder="Address">
			<p> Payment Method:</p>
			
			<input type="radio"  name="pay" placeholder="card" value="card" checked="checked"><label>Card</label><br>
			<input type="text"  name="card_number"  id="card_number" placeholder="Enter 16 digit card number">
			<input type="text"  name="cvv"  id="cvv" placeholder="Enter CVV">
            <input type="radio"  name="pay" placeholder="cash" value="cash" ><label>Cash</label><br>
			<script>
            $(document).ready(function() {
                $('input[name="pay"]').click(function() 
                {
                    // Hide 2 divs
                    $('#card_number').hide();
                     $('#cvv').hide();
                    // Show by current checkbox
                    var value = $(this).val();
                    if (value == 'card'){
                        $('#card_number').show();
                         $('#cvv').show();
                    }
                });
            });
        </script>
			<button type="submit" name="proceed">Proceed to pay</button>
		</form>
	</div>
</section>
</body>
</html>
<?php

}
else{
	include_once 'mycart.php';
	 echo '<script>alert("Login to Continue")</script>'; 
}

?>