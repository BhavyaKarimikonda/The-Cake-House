<?php
    include_once 'header.php';
    ?>

<section class="main-container">
	<div class="main-wrapper">
		<p id="open"> Welcome to the cake factory!<br/></p>
		<p id="mid">  We are here to make your special moments memorable with our delicious cup cakes...</p>
			<?php echo '<form action="cakes.php" method="POST" >
					<button type="submit" name="explore">Click to explore our cakes</button>
				</form>' ; ?>
		<?php
	//	if(isset($_SESSION['u_id'])){
	//		echo " ";
	//	}
		?>
	</div>
</section>

<?php
    include_once 'footer.php';
    ?>

