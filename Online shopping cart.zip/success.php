<?php
    include_once 'header.php';
    ?>
    <br> <br> <br> <br>
    <p style="text-align: center; font-size: 25px;">Order placed successfully</p>


    <div style="float: left; width: 130px">
      <form method="POST" action="cakes.php"> <?php
      echo "<br>"; echo "<br>"; echo "<br>";echo "<br>"; echo "<br>"; echo "<br>";echo "<br>"; echo "<br>"; echo "<br>";echo "<br>"; echo "<br>"; echo "<br>";
      echo '<input type="submit" name="continue_shopping" style="margin-left:200px;font-size:20px;font-family:cursive;color:#fff;background-color:#814F12; cursor: pointer;" value="Continue Shopping"/>' ; ?>
      </form>
</div>